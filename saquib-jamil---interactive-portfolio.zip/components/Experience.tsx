import React from 'react';
import { RESUME_DATA } from '../constants';
import { Briefcase } from 'lucide-react';

const Experience: React.FC = () => {
  return (
    <section id="experience" className="py-20 px-6 md:px-12 bg-slate-900/50">
      <div className="max-w-5xl mx-auto">
        <div className="flex items-center gap-4 mb-12">
          <div className="p-3 bg-brand-accent/10 rounded-xl text-brand-accent">
            <Briefcase size={32} />
          </div>
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-slate-100">Experience</h2>
        </div>

        <div className="relative border-l border-slate-700 ml-3 md:ml-6 space-y-12">
          {RESUME_DATA.experience.map((job, index) => (
            <div key={job.id} className="relative pl-8 md:pl-12 group">
              {/* Timeline Dot */}
              <div className="absolute -left-[5px] md:-left-[9px] top-2 w-3 h-3 md:w-5 md:h-5 rounded-full border-2 border-brand-accent bg-brand-dark group-hover:bg-brand-accent transition-colors duration-300"></div>
              
              <div className="bg-slate-800/50 hover:bg-slate-800 p-6 rounded-xl border border-slate-700/50 hover:border-brand-accent/30 transition-all duration-300 shadow-lg">
                <div className="flex flex-col md:flex-row md:justify-between md:items-start mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-white group-hover:text-brand-accent transition-colors">{job.role}</h3>
                    <h4 className="text-slate-400 font-medium">{job.company}</h4>
                  </div>
                  <div className="mt-2 md:mt-0 text-sm font-mono text-slate-500 bg-slate-900/50 px-3 py-1 rounded-md border border-slate-700 inline-block">
                    {job.period}
                  </div>
                </div>
                
                <ul className="space-y-2">
                  {job.description.map((desc, i) => (
                    <li key={i} className="flex items-start gap-2 text-slate-300 text-sm md:text-base">
                      <span className="mt-2 w-1.5 h-1.5 rounded-full bg-slate-500 shrink-0"></span>
                      <span>{desc}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;