import React from 'react';
import { RESUME_DATA } from '../constants';
import { GraduationCap, Award, Zap } from 'lucide-react';

const Skills: React.FC = () => {
  return (
    <section id="skills" className="py-20 px-6 md:px-12 relative overflow-hidden">
      {/* Background accent */}
      <div className="absolute top-1/2 right-0 w-[500px] h-[500px] bg-blue-900/20 rounded-full blur-[100px] -z-10"></div>

      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-12">
        
        {/* Education Column */}
        <div>
            <div className="flex items-center gap-3 mb-8">
                <GraduationCap className="text-brand-accent" size={28} />
                <h2 className="text-3xl font-serif font-bold">Education</h2>
            </div>
            <div className="space-y-6">
                {RESUME_DATA.education.map((edu) => (
                    <div key={edu.id} className="p-6 bg-slate-800/40 rounded-xl border-l-4 border-l-brand-accent hover:bg-slate-800/60 transition-colors">
                        <h3 className="text-xl font-bold text-white">{edu.institution}</h3>
                        <p className="text-brand-accent/80 font-medium">{edu.degree}</p>
                        <p className="text-slate-400 text-sm mt-1">{edu.period}</p>
                        {edu.details && <p className="text-slate-300 text-sm mt-3 italic">"{edu.details}"</p>}
                    </div>
                ))}
            </div>

            <div className="flex items-center gap-3 mb-8 mt-12">
                <Award className="text-brand-accent" size={28} />
                <h2 className="text-3xl font-serif font-bold">Certifications</h2>
            </div>
            <div className="flex flex-wrap gap-3">
                {RESUME_DATA.certifications.map((cert, idx) => (
                    <div key={idx} className="px-4 py-2 bg-slate-800 rounded-lg text-sm text-slate-300 border border-slate-700 hover:border-brand-accent transition-colors cursor-default">
                        {cert.name}
                    </div>
                ))}
            </div>
        </div>

        {/* Skills Column */}
        <div>
             <div className="flex items-center gap-3 mb-8">
                <Zap className="text-brand-accent" size={28} />
                <h2 className="text-3xl font-serif font-bold">Top Skills</h2>
            </div>
            
            <div className="grid gap-6">
                {RESUME_DATA.skills.map((skillGroup, idx) => (
                    <div key={idx} className="bg-gradient-to-br from-slate-800 to-slate-900 p-6 rounded-2xl border border-slate-700/50">
                        <h3 className="text-lg font-semibold text-white mb-4 border-b border-slate-700 pb-2">
                            {skillGroup.category}
                        </h3>
                        <div className="flex flex-wrap gap-2">
                            {skillGroup.items.map((skill, sIdx) => (
                                <span key={sIdx} className="px-3 py-1 bg-brand-accent/10 text-brand-accent text-sm rounded-full font-medium">
                                    {skill}
                                </span>
                            ))}
                        </div>
                    </div>
                ))}
            </div>

            {/* Creative visual filler */}
            <div className="mt-8 p-6 bg-slate-800/30 rounded-2xl border border-dashed border-slate-700 text-center">
                <p className="text-slate-400 italic">
                    "Driven by data, inspired by people."
                </p>
            </div>
        </div>

      </div>
    </section>
  );
};

export default Skills;