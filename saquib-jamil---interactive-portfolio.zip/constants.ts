import { ProfileData } from './types';

// NOTE: In a real deployment, replace 'profile_placeholder.jpg' with the actual uploaded image file path.
// Since I cannot save the file directly to your disk in this environment, I am simulating the import.
// Please place the image named 'profile.png' in your public folder or src assets.
export const PROFILE_IMAGE_URL = "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=600&auto=format&fit=crop"; 

export const RESUME_DATA: ProfileData = {
  name: "Saquib Jamil",
  title: "Media & Advocacy | Trust & Safety | Gender Justice",
  location: "New Delhi, Delhi, India",
  email: "saquibreja7@gmail.com",
  phone: "7011925439",
  linkedin: "linkedin.com/in/saquibjamil",
  summary: "Hello! I'm Saquib, a passionate and dedicated individual with a strong background in research, public policy, and community engagement. My journey has taken me from earning a Master’s degree in Development Studies to gaining hands-on experience in various impactful roles. I believe in the power of people and policy to drive positive change. Whether it's through research, community work, or digital advocacy, I'm committed to making a difference.",
  experience: [
    {
      id: "csr-project",
      company: "Centre for Social Research India",
      role: "Project Coordinator, Trust and Safety",
      period: "Nov 2024 - Present", 
      location: "New Delhi, Delhi, India",
      description: [
        "Coordinating projects on online safety, digital well-being, and women’s protection in digital spaces.",
        "Managing collaborations with tech companies, policymakers, and civil society to enhance digital trust.",
        "Overseeing logistics, partnerships, and communications for the Trust & Safety India Festival (TASI)."
      ]
    },
    {
      id: "comm-assoc",
      company: "Communication Associate",
      role: "Communication Associate",
      period: "Nov 2024 - Present",
      location: "New Delhi, Delhi, India",
      description: [
        "Supported advocacy campaigns promoting women’s empowerment, safety, and digital rights.",
        "Managed digital content to raise awareness on gender-based violence and online well-being.",
        "Collaborated with media and tech partners to amplify messages on trust, safety, and inclusion."
      ]
    },
    {
      id: "samsung",
      company: "Samsung India",
      role: "Samsung Members Star | Community Moderation",
      period: "July 2022 - Present",
      location: "New Delhi, Delhi, India",
      description: [
        "Moderated the Samsung Members App community to ensure safe, guideline-compliant engagement.",
        "Led 20+ digital campaigns ensuring integrity, transparency, and user safety.",
        "Represented the community at 10+ Samsung product launches."
      ]
    },
    {
      id: "ambedkar-placement",
      company: "Ambedkar University, Delhi",
      role: "Student Placement Coordinator",
      period: "Feb 2024 - June 2024",
      location: "Delhi, India",
      description: [
        "Served as member of Placement Committee, organizing trainings and workshops.",
        "Facilitated student-employer connections for better job placements."
      ]
    },
    {
      id: "csr-intern",
      company: "Centre for Social Research India",
      role: "Research Intern",
      period: "June 2023 - July 2023",
      location: "New Delhi, Delhi, India",
      description: [
        "Assisted in research on water conservation and water scarcity.",
        "Conducted fieldwork in 33 villages of Alwar district.",
        "Performed data entry and analysis for 350+ respondents."
      ]
    },
    {
      id: "iff-volunteer",
      company: "Internet Freedom Foundation",
      role: "Volunteer",
      period: "March 2021 - June 2021",
      location: "Delhi, India",
      description: [
        "Monitored online platforms for digital rights violations.",
        "Participated in online forums and discussions to advocate for digital rights."
      ]
    },
    {
      id: "aashman",
      company: "Aashman Foundation",
      role: "Social Media Coordinator",
      period: "April 2021 - June 2021",
      location: "New Delhi, Delhi, India",
      description: [
        "Executed targeted social media campaigns resulting in significant engagement growth."
      ]
    }
  ],
  education: [
    {
      id: "masters",
      institution: "Ambedkar University, Delhi",
      degree: "Master's degree, Development Studies",
      period: "Nov 2022 - July 2024",
      details: "Focused on Policy, Protection & Participation"
    },
    {
      id: "bachelors",
      institution: "Jamia Millia Islamia",
      degree: "Major in Political Science & Government",
      period: "2018 - 2021"
    },
    {
      id: "school",
      institution: "Jawahar Navodaya Vidyalaya (JNV)",
      degree: "Intermediate, Physics, Chemistry, Math",
      period: ""
    }
  ],
  skills: [
    {
      category: "Advocacy & Strategy",
      items: ["Policy Advocacy", "Project Planning", "Stakeholder Partnership", "Trust & Safety", "Gender Justice"]
    },
    {
      category: "Media & Tech",
      items: ["Social Media Marketing", "Digital Rights", "Content Strategy", "Community Moderation"]
    },
    {
      category: "Creative",
      items: ["Photography", "Photo Composition", "Digital Image Post-Production"]
    }
  ],
  certifications: [
    { name: "National Level Awareness Programme (NLAP)" },
    { name: "Principles of Photo Composition and Digital Image Post-Production" },
    { name: "Cameras, Exposure, and Photography" },
    { name: "Social Media Marketing Foundations" }
  ]
};