import React from 'react';
import { RESUME_DATA } from '../constants';
import { ArrowDown, Mail, Linkedin, Phone } from 'lucide-react';

// Attempting to use the attached image style if user replaced it, otherwise fallback
// In a real scenario, this src would point to the exact file provided.
const ProfileImage = () => (
  <div className="relative w-64 h-64 md:w-80 md:h-80 mx-auto mb-8 md:mb-0 md:mr-12 shrink-0 group">
    {/* Decorative blob behind */}
    <div className="absolute top-0 -left-4 w-72 h-72 bg-brand-accent/20 rounded-full blur-3xl group-hover:bg-brand-accent/30 transition-all duration-700"></div>
    <div className="relative w-full h-full rounded-2xl overflow-hidden border-2 border-brand-accent/50 shadow-2xl rotate-3 group-hover:rotate-0 transition-all duration-500 ease-out">
      {/* 
         IMPORTANT: To use the user's specific image, replace the src below with:
         src={require('../assets/user_image.jpg')} or similar depending on build system
      */}
      <img 
        src="https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?q=80&w=800&auto=format&fit=crop" 
        alt={RESUME_DATA.name}
        className="w-full h-full object-cover scale-110 group-hover:scale-100 transition-transform duration-700"
      />
      <div className="absolute inset-0 bg-brand-accent/10 group-hover:bg-transparent transition-colors duration-300"></div>
    </div>
  </div>
);

const Hero: React.FC = () => {
  return (
    <section id="about" className="min-h-screen flex flex-col justify-center relative pt-20 pb-12 px-6 md:px-12 overflow-hidden">
      {/* Background elements */}
      <div className="blob w-96 h-96 bg-purple-900/30 rounded-full top-0 left-0 mix-blend-multiply"></div>
      <div className="blob w-96 h-96 bg-cyan-900/30 rounded-full bottom-0 right-0 mix-blend-multiply animation-delay-2000"></div>

      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center">
        <ProfileImage />
        
        <div className="text-center md:text-left z-10">
          <div className="inline-block px-3 py-1 mb-4 text-xs font-semibold tracking-wider text-brand-accent uppercase bg-brand-accent/10 rounded-full">
            Media & Advocacy Professional
          </div>
          <h1 className="text-5xl md:text-7xl font-serif font-bold mb-4 bg-clip-text text-transparent bg-gradient-to-r from-slate-100 to-slate-400">
            {RESUME_DATA.name}
          </h1>
          <h2 className="text-xl md:text-2xl text-slate-400 mb-6 font-light">
            {RESUME_DATA.title}
          </h2>
          <p className="text-slate-300 max-w-xl text-lg leading-relaxed mb-8 mx-auto md:mx-0">
            {RESUME_DATA.summary}
          </p>
          
          <div className="flex flex-wrap gap-4 justify-center md:justify-start">
            <a href={`mailto:${RESUME_DATA.email}`} className="flex items-center gap-2 px-6 py-3 bg-brand-accent hover:bg-cyan-500 text-brand-dark font-bold rounded-lg transition-all transform hover:-translate-y-1 shadow-[0_0_20px_rgba(6,182,212,0.3)]">
              <Mail size={18} />
              Contact Me
            </a>
            <a href={`https://${RESUME_DATA.linkedin}`} target="_blank" rel="noreferrer" className="flex items-center gap-2 px-6 py-3 border border-slate-600 hover:border-slate-400 text-slate-300 hover:text-white rounded-lg transition-all hover:bg-slate-800">
              <Linkedin size={18} />
              LinkedIn
            </a>
          </div>
        </div>
      </div>

      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 animate-bounce text-slate-500">
        <ArrowDown size={24} />
      </div>
    </section>
  );
};

export default Hero;