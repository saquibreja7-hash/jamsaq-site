import React from 'react';
import { RESUME_DATA } from '../constants';
import { Mail, Phone, Linkedin, MapPin } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <footer id="contact" className="bg-slate-950 py-16 px-6 border-t border-slate-800">
      <div className="max-w-4xl mx-auto text-center">
        <h2 className="text-3xl md:text-5xl font-serif font-bold text-white mb-8">Let's Connect</h2>
        <p className="text-slate-400 mb-12 max-w-xl mx-auto">
          I'm always open to discussing new projects, creative ideas, or opportunities to be part of your vision for a safer digital future.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          <a href={`mailto:${RESUME_DATA.email}`} className="flex flex-col items-center gap-3 p-6 rounded-xl bg-slate-900 hover:bg-slate-800 transition-all group">
            <div className="w-12 h-12 bg-slate-800 group-hover:bg-brand-accent rounded-full flex items-center justify-center transition-colors">
              <Mail className="text-white" size={20} />
            </div>
            <span className="text-slate-300 text-sm">{RESUME_DATA.email}</span>
          </a>

          <div className="flex flex-col items-center gap-3 p-6 rounded-xl bg-slate-900 group">
             <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center text-brand-accent">
              <Phone size={20} />
            </div>
            <span className="text-slate-300 text-sm">{RESUME_DATA.phone}</span>
          </div>

          <div className="flex flex-col items-center gap-3 p-6 rounded-xl bg-slate-900 group">
             <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center text-brand-accent">
              <MapPin size={20} />
            </div>
            <span className="text-slate-300 text-sm">{RESUME_DATA.location}</span>
          </div>
        </div>

        <div className="text-slate-600 text-sm">
          &copy; {new Date().getFullYear()} {RESUME_DATA.name}. All Rights Reserved.
        </div>
      </div>
    </footer>
  );
};

export default Contact;